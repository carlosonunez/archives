#!/usr/bin/env bash
#Starts a Bitbucket Server instance.

if ! docker-compose -f $PWD/bitbucket_server_test/docker-compose.yml down bitbucket_server
then
  >&2 echo "ERROR: Failed to start Bitbucket server."
  exit 1
fi
