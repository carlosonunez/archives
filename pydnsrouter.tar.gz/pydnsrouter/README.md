# dnslabelrouter
Yet another simple third-level DNS redirection service written in Python.
