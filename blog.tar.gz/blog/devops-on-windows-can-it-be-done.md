* Typical situation in which this situation would be relevant
* Stereotypical Windows v. Linux arguments
* YES, DEVOPS AND WINDOWS CAN HAPPEN
* "What is DevOps" is out of scope
* Examples of companies/teams doing this
* Fundamental DevOps toolkits
  * Continuous Delivery
  * Configuration Management
  * Infrastructure as Code
