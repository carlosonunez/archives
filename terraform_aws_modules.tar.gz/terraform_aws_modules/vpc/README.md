# Carlos's AWS VPC module

This is a simple Terraform module that creates a VPC and an internet gateway.
Because this module will be used for my internal projects, the following are not supported:

- ClassicLink
- Dedicated Tenancy
- IPv6.

# Testing

**NOTE**: You will need an AWS account to perform these tests. These tests will cost you money.

1. Copy `.env.example` to `.env` and replace "change me" with real values.
2. Run `make run_tests` to deploy the VPC, run tests against it and tear down everything when done.

# Module Inputs

## Required

* `aws_access_key_id`: The AWS access key to use for this deployment.
* `aws_secret_access_key`: The AWS secret access key for `aws_access_key_id`
* `aws_region`: The AWS region into which this VPC will be deployed.
* `cidr_block`: The CIDR block to use for resources created within this VPC.
* `tags`: A key-value block of tags to apply onto this instance. 
  They should look like the following:

  ```
  {
    key = value
  }
  ```

## Optional

* `disable_dns_support`: (False) Disable the AWS VPC DNS server and all VPC DNS services.
* `disable_dns_hostnames`: (False) Prevents instances launched in this VPC from receiving hostnames.
* `disable_internet_gateway`: (False) Disables automated creation of the VPC internet gateway.
  If this is set to `true`, you will need to provision the internet gateway yourself
  or provision a NAT instance.

# Module Outputs

* `aws_vpc_id`: The ID for the VPC.
* `aws_vpc_cidr_block`: The CIDR block provisioned for the VPC.
* `aws_vpc_main_route_table_id`: The default route table for the VPC
  (Includes routes to the internet gateway)
* `aws_vpc_igw_id`: The ID of the internet gateway.
