This is a collection of Terraform modules for AWS. You can find more details
about each module within the folders above.
