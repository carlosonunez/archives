[![Build Status](https://travis-ci.org/carlosonunez/kubernetes_aws.svg?branch=master)](https://travis-ci.org/carlosonunez/kubernetes_aws)

What is this?
=============

So I needed to become a Certified Kubernetes Administrator...fast. What's the 
fastest way to learn anything? To just fucking do it.

So I did that.

This repository is an example of how to bring up Kubernetes from scratch. It 
largely follows Kelsey Hightower and friends excellent tutorial,
[Kubernetes, The Hard Way](https://github.com/kelseyhightower/kubernetes-the-hard-way),
with adaptations for AWS. It uses Terraform, Packer and Ansible in the first instance
to bring this infrastructure up.

To add additional pain, I will be running all of my services on top of this cluster.
In other words, this repository deprecates
[my older attempt at this](https://github.com/carlosonunez/carlosnunez-me-infrastructure).

How do I deploy it?
===================

Requirements
------------
- Mac OS X or Linux
- Docker version 17.03-ce or greater

### NOTE
Ubuntu on Windows will not work, as these images require that the working directory 
be bind-mounted, and WSL does not properly support bind-mounting from volumes inside of
the subsystem.

See [this issue](https://github.com/docker/compose/issues/4852) for more information.

Instructions
------------

1. (Optional) Generate a ".env" file: `make env`
2. Open `.env` and replace the dummy values with real ones.
3. Ensure that the recent commit is good: `make unit_test`
4. Deploy it: `make deploy`

### NOTE

`deploy` will also run:

- `make provision`: Provisions Kubernetes on top of the newly-created infrastructure.
- `make integration_tests`: Runs integration tests against it to ensure that all is well.


How do the branches work?
=========================

I only commit to `master`. To find "stable" versions of `carlosnunez.me`, take 
a look at the tags.

###NOTE

If you want to see a super granular history of every edit I made to this project, 
check the reflog: `git reflog`.

I want to copy this/suggest improvements! How can I do that?
=============================================================

1. Drop a pull request!
2. Fork it!
3. Email me: dev@carlosnunez.me!
