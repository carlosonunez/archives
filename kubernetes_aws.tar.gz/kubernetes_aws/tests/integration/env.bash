#!/usr/bin/env bash
KUBERNETES_WORKER_HOSTS_FILE="$PWD/work/kube_worker_addresses"
KUBERNETES_CONTROLLER_HOSTS_FILE="$PWD/work/kube_controller_addresses"
KUBERNETES_CONTROLLER_INTERNAL_HOSTS_FILE="$PWD/work/kube_internal_controller_ips"
