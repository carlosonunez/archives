#!/usr/bin/bash
etcd_member_list=""
ssh_private_key_file=work/ssh_private_key
internal_ip_addresses_file=work/kube_internal_controller_ips
public_ip_addresses_file=work/kube_controller_addresses

while read -r internal_controller_ip_address
do
  controller_hostname="controller-$(echo "$internal_controller_ip_address" | tr '.' '-')"
  etcd_member_list="${etcd_member_list}${controller_hostname}=https://${internal_controller_ip_address}:2380,"
done < <(< "$internal_ip_addresses_file" tr -d $'\r')

etcd_member_list=$(echo "$etcd_member_list" | head -c -2)
while read -r controller_ip_address
do
  controller_private_ip_address=$(ssh -n -o 'StrictHostKeyChecking=no' \
    -o 'ConnectTimeout=3' \
    -i "$ssh_private_key_file" \
    ubuntu@"$controller_ip_address" \
    'ifconfig eth0 | grep "inet addr" | cut -f2 -d: | cut -f1 -d" "')
  validated_controller_private_ip_address=$(echo "$controller_private_ip_address" | \
    grep -E -- '^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
  )
  if [ -z "$validated_controller_private_ip_address" ]
  then
    echo "ERROR: This is not a valid IP address: $controller_private_ip_address" >&2
    exit 1
  fi
	controller_hostname="controller-$(echo "$validated_controller_private_ip_address" | tr '.' '-')"
	local_etcd_file="work/etcd_${controller_hostname}.service"
	echo "INFO: Creating etcd.service for etcd member [$controller_hostname]"
  cat > "$local_etcd_file" <<EOF
[Unit]
Description=etcd
Documentation=https://github.com/coreos

[Service]
ExecStart=/usr/local/bin/etcd \\
  --name ${controller_hostname} \\
  --cert-file=/etc/etcd/kubernetes.pem \\
  --key-file=/etc/etcd/kubernetes-key.pem \\
  --peer-cert-file=/etc/etcd/kubernetes.pem \\
  --peer-key-file=/etc/etcd/kubernetes-key.pem \\
  --trusted-ca-file=/etc/etcd/ca.pem \\
  --peer-trusted-ca-file=/etc/etcd/ca.pem \\
  --peer-client-cert-auth \\
  --client-cert-auth \\
  --initial-advertise-peer-urls https://${validated_controller_private_ip_address}:2380 \\
  --listen-peer-urls https://${validated_controller_private_ip_address}:2380 \\
  --listen-client-urls https://${validated_controller_private_ip_address}:2379,http://127.0.0.1:2379 \\
  --advertise-client-urls https://${validated_controller_private_ip_address}:2379 \\
  --initial-cluster-token etcd-cluster-0 \\
  --initial-cluster ${etcd_member_list} \\
  --initial-cluster-state new \\
  --data-dir=/var/lib/etcd
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
	echo "INFO: Uploading etcd.service to etcd member [$controller_hostname]"
  destination_file_path="/home/ubuntu/etcd.service"
	scp -q -o 'StrictHostKeyChecking=no' \
		-o 'ConnectTimeout=3' \
		-i "$ssh_private_key_file" \
		"$local_etcd_file" ubuntu@"$controller_ip_address":"$destination_file_path"
  if ! ssh -n -o 'StrictHostKeyChecking=no' \
    -o 'ConnectTimeout=3' \
    -i "$ssh_private_key_file" \
    ubuntu@"$controller_ip_address" \
    "sudo mkdir -p /etc/etcd /var/lib/etcd && \
sudo cp ca.pem kubernetes-key.pem kubernetes.pem /etc/etcd/ && \
sudo mv ~/etcd.service /etc/systemd/system && \
sudo systemctl daemon-reload && \
sudo systemctl enable etcd && \
sudo systemctl start etcd"
  then
    echo "ERROR: Failed to start etcd on $controller_ip_address"
  fi
done < <(< "$public_ip_addresses_file" tr -d $'\r')
