#!/usr/bin/env bash

encryption_key=$(head -c 32 /dev/urandom | \
  base64
)
if [ ! -z "$encryption_key" ]
then
  echo "$encryption_key" > "work/cluster_encryption_key"
fi
