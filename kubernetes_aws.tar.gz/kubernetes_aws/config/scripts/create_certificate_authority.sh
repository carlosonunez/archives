#!/usr/bin/env bash

WORKDIR="${PWD}/work"
CA_CONFIG_PATH="${WORKDIR}/ca-config.json"
CA_CSR_PATH="${WORKDIR}/ca-csr.json"
CA_CERTIFICATE_PATH="${WORKDIR}/ca.pem"
CA_PRIVATE_KEY_PATH="${WORKDIR}/ca-key.pem"

mkdir -p "$WORKDIR"

echo "INFO: Creating certificate authority configuration."
cat > "$CA_CONFIG_PATH" <<EOF
{
  "signing": {
    "default": {
      "expiry": "8760h"
    },
    "profiles": {
      "kubernetes": {
        "usages": ["signing", "key encipherment", "server auth", "client auth"],
        "expiry": "8760h"
      }
    }
  }
}
EOF

echo "INFO: Creating CA signing request."
cat > "$CA_CSR_PATH" <<EOF
{
  "CN": "Kubernetes",
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "US",
      "L": "Dallas",
      "O": "Kubernetes",
      "OU": "TX",
      "ST": "Texas"
    }
  ]
}
EOF

echo "INFO: Generating CA certificate and private key."
if ! { cfssl gencert -initca "${CA_CSR_PATH}" | cfssljson -bare ca; } &> /dev/null
then
  echo "ERROR: Couldn't generate CA private key and certificate." >&2
  exit 1
fi
mv ca-key.pem "$CA_PRIVATE_KEY_PATH"
mv ca.pem "$CA_CERTIFICATE_PATH"
