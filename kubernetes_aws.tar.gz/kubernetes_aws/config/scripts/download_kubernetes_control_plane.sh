#!/usr/bin/env bash
kube_controller_addresses_file=work/kube_controller_addresses
ssh_private_key_file=work/ssh_private_key

for file in "$kube_controller_addresses_file" "$ssh_private_key_file"
do
  if [ ! -f "$file" ]
  then
    echo "ERROR: File missing - $file" >&2
    exit 1
  fi
done

kcp_base_uri="https://storage.googleapis.com/kubernetes-release/release/v1.8.0/bin/linux/amd64/"
while read -r controller_ip_address
do
  for file in "kube-apiserver" \
    "kube-controller-manager" \
    "kube-scheduler" \
    "kubectl"
  do
    kcp_file_uri="${kcp_base_uri}/${file}"
    echo "INFO: Installing $file on $controller_ip_address"
    read -r -d '' ssh_command <<-EOF
    ssh -n -o 'StrictHostKeyChecking=no' -o 'ConnectTimeout=3' \
      -i "$ssh_private_key_file" \
      ubuntu@$controller_ip_address \
      "curl -sL -o ${file} ${kcp_file_uri} && \
        chmod +x "${file}" && \
        sudo mv "${file}" /usr/local/bin/"
EOF
    if ! eval "$ssh_command"
    then
      echo "ERROR: Failed to install etcd on $controller_ip_address" >&2
      exit 1
    fi
  done
done < <(< "$kube_controller_addresses_file" tr -d $'\r')
