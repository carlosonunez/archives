#!/usr/bin/env bash
WORKDIR="${PWD}/work"
KUBE_PROXY_CSR_PATH="${WORKDIR}/kube_proxy.csr"
KUBE_PROXY_CERTIFICATE_PATH="${WORKDIR}/kube_proxy.pem"
KUBE_PROXY_PRIVATE_KEY_PATH="${WORKDIR}/kube_proxy-key.pem"
CA_CONFIG_PATH="${WORKDIR}/ca-config.json"
CA_CERTIFICATE_PATH="${WORKDIR}/ca.pem"
CA_PRIVATE_KEY_PATH="${WORKDIR}/ca-key.pem"

echo "INFO: Creating CSR for kube-proxy"
cat > "$KUBE_PROXY_CSR_PATH" <<EOF
{
  "CN": "system:kube-proxy",
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "US",
      "L": "Dallas",
      "O": "system:node-proxier",
      "OU": "Kubernetes The Hard Way",
      "ST": "Texas"
    }
  ]
}
EOF

echo "INFO: Creating certificate and private key for kube-proxy"
if ! { cfssl gencert \
      -ca="${CA_CERTIFICATE_PATH}" \
      -ca-key="${CA_PRIVATE_KEY_PATH}" \
      -config="${CA_CONFIG_PATH}" \
      -profile=kubernetes \
      "${KUBE_PROXY_CSR_PATH}" | cfssljson -bare "kube_proxy"; } &> /dev/null
then
  echo "ERROR: Could not create certificate." >&2
  exit 1
fi

mv kube_proxy.pem "${KUBE_PROXY_CERTIFICATE_PATH}"
mv kube_proxy-key.pem "${KUBE_PROXY_PRIVATE_KEY_PATH}"
