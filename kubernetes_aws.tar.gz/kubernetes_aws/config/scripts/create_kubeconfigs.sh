#!/usr/bin/bash
kube_worker_addresses_file=work/kube_worker_addresses
kube_controller_addresses_file=work/kube_controller_addresses
if [ ! -f "$kube_worker_addresses_file" ]
then
  echo "ERROR: Worker IP addresses file not found at $kube_worker_addresses_file" >&2
  exit 1
fi
if [ ! -f "$kube_controller_addresses_file" ]
then
  echo "ERROR: controller IP addresses file not found at $kube_controller_addresses_file" >&2
  exit 1
fi

# Yeah, I totally forgot to provision an ELB. To save time, we're going to
# just pick the first controller in our list and set it to that.
# A future version of this infrastructure will have corrected this.
kube_controller_to_use=$(<"$kube_controller_addresses_file" tr -d $'\r' | head -n 1)
while read -r worker_ip_address
do
  worker_hostname="ip-$(echo "$worker_ip_address" | tr '.' '-')"
  cluster_config_command=$(cat <<EOF
set-cluster carlosnunez.me \
  --certificate-authority=work/ca.pem \
  --embed-certs=true \
  --server=https://${kube_controller_to_use}:6443 \
  --kubeconfig=work/${worker_hostname}.kubeconfig
EOF
)
  credentials_config_command=$(cat <<EOF
set-credentials system:node:${worker_hostname} \
  --client-certificate=work/worker_${worker_hostname}.pem \
  --client-key=work/worker_${worker_hostname}-key.pem \
  --embed-certs=true \
  --kubeconfig=work/${worker_hostname}.kubeconfig
EOF
)
  cluster_context_config_command=$(cat <<EOF
set-context default \
  --cluster=carlosnunez.me \
  --user=system:node:${worker_hostname}.kubeconfig \
  --kubeconfig=work/${worker_hostname}.kubeconfig
EOF
)
  enable_context_command=$(cat <<EOF
use-context default --kubeconfig=work/${worker_hostname}.kubeconfig
EOF
)
  for partial_kubectl_command in "$cluster_config_command" \
    "$credentials_config_command" \
    "$cluster_context_config_command" \
    "$enable_context_command"
  do
    kubectl_command="kubectl config $partial_kubectl_command"
    if ! eval "$kubectl_command" &> /dev/null
    then
      echo "ERROR: Failed to create kubeconfig for $worker_hostname" >&2
      break
    fi
  done
done < <(< "$kube_worker_addresses_file" tr -d $'\r')
