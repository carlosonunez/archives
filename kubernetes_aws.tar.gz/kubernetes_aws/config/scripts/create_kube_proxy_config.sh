#!/usr/bin/bash
kube_controller_addresses_file=work/kube_controller_addresses
if [ ! -f "$kube_controller_addresses_file" ]
then
  echo "ERROR: controller IP addresses file not found at $kube_controller_addresses_file" >&2
  exit 1
fi

# Yeah, I totally forgot to provision an ELB. To save time, we're going to
# just pick the first controller in our list and set it to that.
# A future version of this infrastructure will have corrected this.
kube_controller_to_use=$(<"$kube_controller_addresses_file" tr -d $'\r' | head -n 1)
cluster_config_command="set-cluster carlosnunez.me \
--certificate-authority=work/ca.pem \
--embed-certs=true \
--server=https://${kube_controller_to_use}:6443 \
--kubeconfig=work/kube_proxy.kubeconfig"

credentials_config_command="set-credentials kube-proxy --embed-certs=true \
--client-certificate=work/kube_proxy.pem \
--client-key=work/kube_proxy-key.pem \
--kubeconfig=work/kube_proxy.kubeconfig"

cluster_context_config_command="set-context default \
--cluster=carlosnunez.me \
--user=kube-proxy \
--kubeconfig=work/kube_proxy.kubeconfig"

enable_context_command="use-context default --kubeconfig=work/kube_proxy.kubeconfig"

for partial_kubectl_command in "$cluster_config_command" \
  "$credentials_config_command" \
  "$cluster_context_config_command" \
  "$enable_context_command"
do
  kubectl_command="kubectl config $partial_kubectl_command"
  if ! eval "$kubectl_command" &> /dev/null
  then
    echo "ERROR: Failed to create kube-proxy.config." >&2
    break
  fi
done
