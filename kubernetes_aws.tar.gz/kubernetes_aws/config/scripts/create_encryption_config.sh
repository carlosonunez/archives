#!/usr/bin/env bash

encryption_key_path="work/cluster_encryption_key"
if [ ! -f "$encryption_key_path" ]
then
  echo "ERROR: Couldn't find encryption key at $encryption_key_path". >&2
  exit 1
fi

encryption_key=$(cat $encryption_key_path)
cat > work/encryption_config.yaml <<EOF
kind: EncryptionConfig
apiVersion: v1
resources:
  - resources:
      - secrets
    providers:
      - aescbc:
          keys:
            - name: key1
              secret: ${encryption_key}
      - identity: {}
EOF
