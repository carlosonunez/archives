#!/usr/bin/env bash

kube_controller_addresses_file=work/kube_controller_addresses
ssh_private_key_file=work/ssh_private_key
for file in "$kube_controller_addresses_file" \
  "$ssh_private_key_file" \
  "work/encryption_config.yaml"
do
  if [ ! -f "$file" ]
  then
    echo "ERROR: Required file is missing - $file" >&2
    exit 1
  fi
done

WORKDIR="${PWD}/work"
while read -r controller_ip_address
do
  echo "INFO: Uploading encryption config to controller $controller_ip_address"
  source_file_path="${WORKDIR}/encryption_config.yaml"
  destination_file_path="/home/ubuntu/encryption_config.yaml"
  scp -q -o 'StrictHostKeyChecking=no' \
    -o 'ConnectTimeout=3' \
    -i "$ssh_private_key_file" \
    "$source_file_path" ubuntu@"$controller_ip_address":"$destination_file_path"
done < <(< "$kube_controller_addresses_file"  tr -d $'\r')
