#!/usr/bin/env bash
kube_worker_addresses_file=work/kube_worker_addresses
kube_controller_addresses_file=work/kube_controller_addresses
ssh_private_key_file=work/ssh_private_key
for file in "$kube_worker_addresses_file" \
  "$kube_controller_addresses_file" \
  "$ssh_private_key_file"
do
  if [ ! -f "$file" ]
  then
    echo "ERROR: Required file is missing - $file" >&2
    exit 1
  fi
done

WORKDIR="${PWD}/work"
while read -r worker_ip_address
do
  echo "INFO: Uploading kubeconfig to worker $worker_ip_address"
  worker_hostname="ip-$(echo "$worker_ip_address" | tr '.' '-')"
  for file in "${worker_hostname}.kubeconfig" \
    "kube_proxy.kubeconfig"
  do
    source_file_path="${WORKDIR}/${file}"
    destination_file_path="/home/ubuntu/${file}"
    scp -q -o 'StrictHostKeyChecking=no' \
      -o 'ConnectTimeout=3' \
      -i "$ssh_private_key_file" \
      "$source_file_path" ubuntu@"$worker_ip_address":"$destination_file_path"
  done
done < <(< "$kube_worker_addresses_file" tr -d $'\r')

while read -r controller_ip_address
do
  echo "INFO: Provisioning controller $controller_ip_address"
  for file in "ca.pem" \
    "ca-key.pem" \
    "kubernetes.pem" \
    "kubernetes-key.pem"
  do
    source_file_path="${WORKDIR}/${file}"
    destination_file_path="/home/ubuntu/${file}"
    scp -q -o 'StrictHostKeyChecking=no' \
      -o 'ConnectTimeout=3' \
      -i "$ssh_private_key_file" \
      "$source_file_path" ubuntu@"$controller_ip_address":"$destination_file_path"
  done
done < <(< "$kube_controller_addresses_file"  tr -d $'\r')
