#!/usr/bin/env bash
kube_worker_addresses_file=work/kube_worker_addresses
ssh_private_key_file=work/ssh_private_key
if [ ! -f "$kube_worker_addresses_file" ]
then
  echo "ERROR: Worker IP addresses file not found at $kube_worker_addresses_file" >&2
  exit 1
fi
if [ ! -f "$ssh_private_key_file" ]
then
  echo "ERROR: SSH private key file not found at $ssh_private_key_file." >&2
  exit 1
fi

WORKDIR="${PWD}/work"
CA_CONFIG_PATH="${WORKDIR}/ca-config.json"
CA_CERTIFICATE_PATH="${WORKDIR}/ca.pem"
CA_PRIVATE_KEY_PATH="${WORKDIR}/ca-key.pem"
while read -r worker_ip_address
do
  worker_hostname="ip-$(echo "$worker_ip_address" | tr '.' '-')"
  WORKER_CSR_PATH="${WORKDIR}/worker_${worker_hostname}.csr"
  WORKER_CERTIFICATE_PATH="${WORKDIR}/worker_${worker_hostname}.pem"
  WORKER_PRIVATE_KEY_PATH="${WORKDIR}/worker_${worker_hostname}-key.pem"
  worker_private_ip_address=$(ssh -n -o 'StrictHostKeyChecking=no' \
    -o 'ConnectTimeout=3' \
    -i "$ssh_private_key_file" \
    ubuntu@"$worker_ip_address" \
    'ifconfig eth0 | grep "inet addr" | cut -f2 -d: | cut -f1 -d" "')
  validated_worker_private_ip_address=$(echo "$worker_private_ip_address" | \
    grep -E -- '^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
  )
  if [ -z "$validated_worker_private_ip_address" ]
  then
    echo "ERROR: This is not a valid IP address: $worker_private_ip_address" >&2
    exit 1
  fi
  echo "INFO: Creating CSR for worker ${worker_hostname} with private address ${worker_private_ip_address}"
  cat > "$WORKER_CSR_PATH" <<EOF
  {
    "CN": "system:node:${worker_hostname}",
    "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
  {
    "C": "US",
    "L": "Dallas",
    "O": "system:nodes",
    "OU": "Kubernetes The Hard Way",
    "ST": "Texas"
  }
  ]
}
EOF

  echo "INFO: Creating certificate and private key for worker ${worker_hostname}"
  if ! { cfssl gencert \
    -ca="${CA_CERTIFICATE_PATH}" \
    -ca-key="${CA_PRIVATE_KEY_PATH}" \
    -config="${CA_CONFIG_PATH}" \
    -hostname="${worker_hostname},${worker_ip_address},${worker_private_ip_address}" \
    -profile=kubernetes \
    "${WORKER_CSR_PATH}" | cfssljson -bare "${worker_hostname}"; } &> /dev/null
  then
    echo "ERROR: Could not create certificate." >&2
    exit 1
  fi

  mv "${worker_hostname}.pem" "${WORKER_CERTIFICATE_PATH}"
  mv "${worker_hostname}-key.pem" "${WORKER_PRIVATE_KEY_PATH}"
done < <(< "$kube_worker_addresses_file" tr -d $'\r')
