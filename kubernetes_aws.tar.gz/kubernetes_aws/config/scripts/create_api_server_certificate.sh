#!/usr/bin/env bash
WORKDIR="${PWD}/work"
KUBERNETES_CSR_PATH="${WORKDIR}/kubernetes.csr"
KUBERNETES_CERTIFICATE_PATH="${WORKDIR}/kubernetes.pem"
KUBERNETES_PRIVATE_KEY_PATH="${WORKDIR}/kubernetes-key.pem"
CA_CONFIG_PATH="${WORKDIR}/ca-config.json"
CA_CERTIFICATE_PATH="${WORKDIR}/ca.pem"
CA_PRIVATE_KEY_PATH="${WORKDIR}/ca-key.pem"
internal_ip_addresses_file=work/kube_internal_controller_ips
public_ip_addresses_file=work/kube_controller_addresses

echo "INFO: Creating CSR for API server"
cat > "$KUBERNETES_CSR_PATH" <<EOF
{
  "CN": "kubernetes",
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "US",
      "L": "Dallas",
      "O": "Kubernetes",
      "OU": "Kubernetes The Hard Way",
      "ST": "Texas"
    }
  ]
}
EOF

echo "INFO: Generating list of subject alternate names."
controller_sans="127.0.0.1,kubernetes.default,"
while read -r internal_controller_ip_address
do
  controller_sans="${controller_sans}${internal_controller_ip_address},"
done < <(< "$internal_ip_addresses_file" tr -d $'\r')
while read -r public_controller_ip_address
do
  controller_sans="${controller_sans}${public_controller_ip_address},"
done < <(< "$public_ip_addresses_file" tr -d $'\r')
controller_sans=$(echo "$controller_sans" | head -c -2)
echo "INFO: List of SANs: $controller_sans"

echo "INFO: Creating certificate and private key for API server"
if ! { cfssl gencert \
      -ca="${CA_CERTIFICATE_PATH}" \
      -ca-key="${CA_PRIVATE_KEY_PATH}" \
      -config="${CA_CONFIG_PATH}" \
      -hostname="$controller_sans" \
      -profile=kubernetes \
      "${KUBERNETES_CSR_PATH}" | cfssljson -bare "kubernetes"; } &> /dev/null
then
  echo "ERROR: Could not create certificate." >&2
  exit 1
fi

mv kubernetes.pem "${KUBERNETES_CERTIFICATE_PATH}"
mv kubernetes-key.pem "${KUBERNETES_PRIVATE_KEY_PATH}"
