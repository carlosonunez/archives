#!/usr/bin/env bash
kube_controller_addresses_file=work/kube_controller_addresses
ssh_private_key_file=work/ssh_private_key

for file in "$kube_controller_addresses_file" "$ssh_private_key_file"
do
  if [ ! -f "$file" ]
  then
    echo "ERROR: File missing - $file" >&2
    exit 1
  fi
done

etcd_installation_uri="https://github.com/coreos/etcd/releases/download/v3.2.8/etcd-v3.2.8-linux-amd64.tar.gz"
while read -r controller_ip_address
do
  echo "INFO: Installing etcd on $controller_ip_address"
  read -r -d '' ssh_command <<-EOF
  ssh -n -o 'StrictHostKeyChecking=no' -o 'ConnectTimeout=3' \
    -i "$ssh_private_key_file" \
    ubuntu@$controller_ip_address \
    "curl -sL -o etcd.tar.gz ${etcd_installation_uri} && \
      tar -xf etcd.tar.gz && \
      sudo mv etcd-v3.2.8-linux-amd64/etcd* /usr/local/bin"
EOF
  if ! eval "$ssh_command"
  then
    echo "ERROR: Failed to install etcd on $controller_ip_address" >&2
    exit 1
  fi
done < <(< "$kube_controller_addresses_file" tr -d $'\r')
