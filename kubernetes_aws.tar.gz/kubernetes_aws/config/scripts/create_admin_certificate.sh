#!/usr/bin/env bash

WORKDIR="${PWD}/work"
ADMIN_CSR_PATH="${WORKDIR}/admin-csr.json"
ADMIN_CERTIFICATE_PATH="${WORKDIR}/admin.pem"
ADMIN_PRIVATE_KEY_PATH="${WORKDIR}/admin-key.pem"
CA_CONFIG_PATH="${WORKDIR}/ca-config.json"
CA_CERTIFICATE_PATH="${WORKDIR}/ca.pem"
CA_PRIVATE_KEY_PATH="${WORKDIR}/ca-key.pem"

mkdir -p "$WORKDIR"

echo "INFO: Creating the CSR for the admin client"
cat > "$ADMIN_CSR_PATH" <<EOF
{
  "CN": "admin",
  "key": {
    "algo": "rsa",
    "size": 2048
  },
  "names": [
    {
      "C": "US",
      "L": "Dallas",
      "O": "system:masters",
      "OU": "Kubernetes The Hard Way",
      "ST": "Texas"
    }
  ]
}
EOF

echo "INFO: Creating admin certificate and private key"
if ! { cfssl gencert \
      -ca="$CA_CERTIFICATE_PATH" \
      -ca-key="$CA_PRIVATE_KEY_PATH" \
      -config="$CA_CONFIG_PATH" \
      -profile=kubernetes \
      "${ADMIN_CSR_PATH}" | cfssljson -bare admin; } &> /dev/null
then
  echo "ERROR: Could not generate admin certificate." >&2
  exit 1
fi

mv admin.pem "${ADMIN_CERTIFICATE_PATH}"
mv admin-key.pem "${ADMIN_PRIVATE_KEY_PATH}"
