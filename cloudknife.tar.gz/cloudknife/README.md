# cloudknife
A fast, simple and service-oriented search and reporting tool for all clouds. 
