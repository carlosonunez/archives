#!/usr/bin/env bash
set -e

export $(egrep -v "^#" .env | xargs)
docker run --rm \
  --tty \
  --entrypoint /bin/sh \
  --volume $PWD:/project caktux/travis-cli \
  -c "travis login -g $TRAVIS_GITHUB_TOKEN; \
    cat .env | while read env_var; \
    do \
      travis encrypt --no-interactive \"\$env_var\" --add env.global; \
    done"
