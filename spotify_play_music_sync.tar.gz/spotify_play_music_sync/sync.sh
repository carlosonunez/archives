#!/usr/bin/env bash
set -e

if [ -f .env ]
then
  export $(egrep -v "^#" .env | xargs)
fi
session_id=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | head -c 8)
container_name="pyportify-$session_id"
/usr/bin/expect <<EOF
log_user 0
spawn docker run \
  --name "$container_name" \
  --rm \
  -it "$PYPORTIFY_DOCKER_IMAGE_NAME" \
  /usr/local/bin/pyportify-copyall
expect "Enter Google email address"
send "$GOOGLE_ACCOUNT_USERNAME\n"
expect "Enter Google password"
send "$GOOGLE_ACCOUNT_ONETIME_PASSWORD\n"
expect "Enter Spotify oauth token"
send "$SPOTIFY_OAUTH_TOKEN\n"
expect EOF
EOF
docker logs -f "$container_name"
