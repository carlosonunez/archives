# What is this?

Syncs your Spotify playlists with Google Play Music to get around Spotify's 3,333 offling song download limit.
This is meant to be run as a `cron` job within Travis CI.

# What do I need to use it?

- A GitHub account (sign up [here](https://github.com))
- Access to Travis-CI (Links to your GitHub account. More info [here](https://travis-ci.org))

# How do I use it?

1. Fork this project into your own GitHub account. **It must be a public repository for this to work.**
2. Create a `.env` from the example provided.

**NOTE**: Your Spotify OAuth token needs to be generated manually, as this requires a browser to work.
See the `.env.example` for the URL from where this can be done.

3. Run `deploy.sh` to update your project's environment variables. The encrypted ones provided will not work from your forked repository.
4. Push your changes: `git commit -m "Updated Google and Spotify creds"; git push`
5. Enable your project [here](https://travis-ci.org/profile)
6. Set up a cron job:
  1. Click on your build, then click on "More Settings" then "Settings"
  2. Scroll down to "Cron Jobs," then configure your job and click "Add."
