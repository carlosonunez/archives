/****************************************************
 * The SNIFFER Usability Library
 * -----------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date Created:	23 February, 2010
 *
 * Description
 * -----------
 * Provides methods which external programs can use
 * to work with SNIFFER.
 *
 ****************************************************/

#ifndef	_SNIFFER_CORE_H
#define _SNIFFER_CORE_H

//----------------------------------------
//	Libraries
//----------------------------------------

#include "sniffer_libraries.hpp"
#include <boost/thread/mutex.hpp>		//Include mutex support for scoped_lock
#include <sstream>

//----------------------------------------
//	Entry point
//----------------------------------------

int _sniffer_cli_main();
int sniffer_core_init();

//----------------------------------------
//	(A) GUI interactivity methods.
//----------------------------------------

vector<string> select_device_gui();					//Device selection mechanism for GUI.
std::string	   get_device_from_name(std::string device_descr);	//Get device ID from name.

//---------------------------------------
//	(B) Console-exclusive methods.
//---------------------------------------

void		print_packet(const char *mode_t);

//--------------------------------------
//	Pcap methods.
//--------------------------------------

int			gui_start_capture(std::string device);		//Starts packet capture for device.
int			gui_stop_capture();							//Stops packet capture, but does not destroy sniffer.
int			gui_end_capture();							//Completely quits and destroys.

int			set_pkt_timeout();					//Sets maximum # of packets to capture.
extern int	get_pkt_timeout();					//Returns packet timeout.

int			gui_set_promisc();					//Sets promiscuous mode for GUI.

u_short		r_ntohs(u_short t);					//Auto network byte order determination.


//----------------------------------------
//	(C) Flag check functions.
//----------------------------------------

extern bool etheraddr_print_enabled();
extern bool check_promisc_status();
extern bool get_handler_status();
extern bool is_gui_running();
extern void gui_set_running();				

//Signal handlers. UNIX only.
//----------------------------
#if defined(UNIX)
void sig_handler(int signal);
#endif

int save_db(const char *name, vector< vector<string> > packetList);		//Saves session to DB.

//String support.
//---------------
void	dcout(std::string msg);
void	dcout_inline(std::string msg);

void	dcout(std::string fcn, std::string msg);
void	dcout_inline(std::string fcn, std::string msg);

//Without function name
//---------------------
void 	dcout(const char *msg);
void 	dcout_inline(const char *msg);

//With function name
//------------------
void 	dcout(const char *fcn, const char *msg);
void	dcout_inline(const char *fcn, const char *msg);

//-------------------------------------------------------
//	Template function declarations
//-------------------------------------------------------

//---------------
// itoch(int)
// ----------
//  Int -> string.
//----------------

//No base overload; assume decimal
//--------------------------------
template <class T>
string itoch(const T &val)
{		
	ostringstream s;
	s << dec << val;
	return s.str();
}

//Std base ctor
//-------------
template <class T>
string itoch(const T &val, ios_base& (*f)(ios_base&)) {
	ostringstream s;
	s << f << val;
	return s.str();
}

/********************************************************
 
 void view_bitstring(template T)
 -------------------------------
	Displays bitstring contained in a memory location.
 
 *******************************************************/

template <class T>
void view_bitstring(const T &val)
{
	for (unsigned int i = 1; i <= (8 * sizeof(T)) ; i++)
	{
		unsigned int _mask = 1 << ((8*sizeof(T)) - i);
		cout << ( (val & _mask) ? '1' : '0' );	//Print '1' if set, '0' if unset
		if (sizeof(T) == sizeof(unsigned char) && i % 4 == 0)		cout << ' ';	//Space by half-byte if char
		else if (i % 8 == 0)										cout << ' ';	//Space by byte if other
	}
	
}

/*****************************************************************
 
 string	print_bitstring(template T)
 ---------------------------------
	Ctor for view_bitstring(...), except stores the bitstring
 
 *****************************************************************/

template<class T>
string print_bitstring(const T &val)
{
	string bitstring = "";			//initialize bitstring.
	for (unsigned int i = 1; i <= (8 * sizeof(T)) ; i++)
	{
		unsigned int _mask = 1 << ((8*sizeof(T)) - i);
		bitstring.append( itoch( (val & _mask) ? '1' : '0' ) );	//Print '1' if set, '0' if unset
		if (sizeof(T) == sizeof(unsigned char) && i % 4 == 0)		bitstring.append(" ");	//Space by half-byte if char
		else if (i % 8 == 0)										bitstring.append(" ");	//Space by byte if other
	}
	
	return bitstring;
	
}	
	

#endif	/*_SNIFFER_CORE_H*/
