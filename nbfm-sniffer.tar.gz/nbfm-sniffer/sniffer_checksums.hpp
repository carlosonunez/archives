/****************************************************
 * The SNIFFER Checksums Library
 * -----------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date Created:	15 April, 2010
 *
 * Description
 * -----------
 * These are checksum calculation methods for various
 * protocols supported by SNIFFER.
 *
 ****************************************************/

#ifndef _SNIFFER_CHECKSUMS_HPP
#define _SNIFFER_CHECKSUMS_HPP

//-------------------------------------
//	SNIFFER libraries.
//-------------------------------------

#include "sniffer_libraries.hpp"

//-------------------------------------
//	Function declarations.
//-------------------------------------

u_short ipv4_checksum(struct ip *i, int len);

#endif