/*******************************************************************************
 * The SNIFFER Generalized Packet Class 
 * -------------------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date created: 	23 April, 2010
 * Last edited:		23 April, 2010
 
 Description:
 Provides a global packet class for easy use in other areas (database, GUI)
 
 ******************************************************************************/
#include "sniffer_pkt.h"

sniffer_pkt *sniffer_pkt::sInstance		=	NULL;		//Global checkflag. Should be NULL or 1.

//Singleton class constructor
//---------------------------
sniffer_pkt *sniffer_pkt::Instance()
{
	if (!sInstance)
		sInstance	=	new sniffer_pkt;
	
	return sInstance;
}

//--------------------------------------------------------------------
//	Fetch function. Collects everything in the pkt and sends it back.
//--------------------------------------------------------------------
std::vector<std::string> sniffer_pkt::get_sniffer_pkt()
{
	std::vector<std::string>		vec;
	
	//Push everything into the vector, if not null
	//---------------------------------------------
	if (!pkt_id.empty())		vec.push_back(pkt_id);
	if (!pkt_type.empty())		vec.push_back(pkt_type);
	if (!src_mac.empty())		vec.push_back(src_mac);
	if (!dst_mac.empty())		vec.push_back(dst_mac);
	if (!src_ip.empty())		vec.push_back(src_ip);
	if (!dst_ip.empty())		vec.push_back(dst_ip);
	if (!general_info.empty())	vec.push_back(general_info);		else vec.push_back("Not available");
	if (!adv_info.empty())		vec.push_back(adv_info);
	
	//Return it.
	//----------
	return vec;
}

//-----------------------------------------------------------------------
//	void clear_pkt:	Clears packet instance when done with it.
//----------------------------------------------------------------------

void	sniffer_pkt::clr_sniffer_pkt()
{
	pkt_type.clear();
	src_mac.clear();
	dst_mac.clear();
	src_ip.clear();
	dst_ip.clear();
	general_info.clear();
	adv_info.clear();
}