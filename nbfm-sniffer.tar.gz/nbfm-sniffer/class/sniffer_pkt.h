/*******************************************************************************
 * The SNIFFER Generalized Packet Class 
 * -------------------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date created: 	23 April, 2010
 * Last edited:		23 April, 2010
 
 Description:
	Provides a global packet class for easy use in other areas (database, GUI)
 
******************************************************************************/

#ifndef	_SNIFFER_PKT_H
#define _SNIFFER_PKT_H

#include <iostream>
#include <string>
#include <vector>

typedef unsigned int u_int;
class sniffer_pkt	
{
public:
	static sniffer_pkt *Instance();						//Protected access function.
	
	//Accessor functions
	//------------------
	inline std::string	get_pkt_id()	{	return pkt_id;	}
	inline std::string	get_pkt_type()	{	return pkt_type;}
	inline std::string	get_src_mac()	{	return src_mac;	}
	inline std::string	get_dst_mac()	{	return dst_mac;	}
	inline std::string	get_src_ip()	{	return src_ip;	}
	inline std::string	get_dst_ip()	{	return dst_ip;	}
	inline std::string	get_g_info()	{	return general_info;	}
	inline std::string	get_a_info()	{	return adv_info;		}
	
	//Setter functions
	//----------------
	void	set_pkt_id(std::string _pkt_id)		{	pkt_id	=	_pkt_id;	}
	void	set_pkt_type(std::string _type)		{	pkt_type =	_type;		}
	void	set_src_mac(std::string _src_mac)	{	src_mac	=	_src_mac;	}
	void	set_dst_mac(std::string _dst_mac)	{	dst_mac	=	_dst_mac;	}
	void	set_src_ip(std::string	_src_ip)	{	src_ip	=	_src_ip;	}
	void	set_dst_ip(std::string	_dst_ip)	{	dst_ip	=	_dst_ip;	}
	void	set_g_info(std::string	_info)		{	general_info	=	_info;	}
	void	set_a_info(std::string	_info)		{	adv_info		=	_info;	}
	
	//Get all
	//-------
	std::vector<std::string>	get_sniffer_pkt();			//Aggregates and sends back all data in sniffer_pkt.
	void						clr_sniffer_pkt();			//Clears the instance when done with it.
	
protected:
	sniffer_pkt(){};								//Protect the class constructor!
	~sniffer_pkt(){};								//Protect the class destructor!
	sniffer_pkt(sniffer_pkt const &);				//Protect the copy constructor!
	sniffer_pkt& operator=(sniffer_pkt const &);	//Protect the assignment constructor!
	static sniffer_pkt *sInstance;					//Class initialization checkflag
	
private:
	std::string		pkt_id;
	std::string		pkt_type;
	std::string		src_mac;
	std::string		dst_mac;
	std::string		src_ip;
	std::string		dst_ip;
	std::string		general_info;
	std::string		adv_info;
};

#endif	/*_SNIFFER_PKT_H*/