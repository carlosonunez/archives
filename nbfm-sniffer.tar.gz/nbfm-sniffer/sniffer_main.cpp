/*******************************************
 * SNIFFER Main.
 * -------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date created: 	23 November, 2009
 * Last edited:		24 March, 2010
 *
 * Summary
 * -------
 * This is an example console application which
 * demonstrates how the sniffer library works.
 * You specify the handle to operate, and this
 * application will loop through it for 1000
 * packets.
 *
 *******************************************/
//---------------------
//	Add the sauce.
//---------------------

#include "sniffer_core.hpp"					//External libraries.
#include "gui/sniffer_gtk_gui.h"			//GUI libraries.
#include "gui/sniffer_gui_error.hpp"		//GUI error libraries.
//--------------------
//	Make the beef!
//--------------------

using namespace std;

//---------------------
//	Make the beef!
//---------------------
int main(int argc, char *argv[])
{
	//Run GUI if no arguments are provided.
	//-------------------------------------
	if (argc == 1)
		_sniffer_gui_main(argc,argv);		//For now, go straight into GUI.
	
	else
	{
		string debug_arg	=	argv[1];	//Only accepts one argument for now.

		//Run command line if "-d" is provided.
		//-------------------------------------
		if ( argc >= 2 && debug_arg == "-d"  )
			_sniffer_cli_main();

		//Throw error for all other cases.
		//--------------------------------
		else
			return _throw_runtime_error("Invalid parameters!",1,true);
	}

	return 0;
}

