/*******************************************************************************
 * The SNIFFER Packet Operations Library.
 * -------------------------------------
 *
 * Carlos Nunez		(cnunez@stevens.edu)
 * Kevin Fuhrman	(ktfuhrman@gmail.com)
 * William Best		(wbest@stevens.edu)
 * Mike DiAmore		(mdiamore@stevens.edu)
 *
 * Description:
 *
 * 		This library contains class definitions for SNIFFER.
 *
 */

#ifndef _SNIFFER_CLASS_DEFS_H
#define _SNIFFER_CLASS_DEFS_H

/*	Packet class
 * 	------------
 *
 *  This packet provides abridged information for packets captured by SNIFFER. It
 *  includes:
 *
 *  	- Data source
 *  	- Data destination
 *  	- Data type
 *  	- Packet ID
 *
 *==========================================================================*/

class pkt
{
	private:
		int packet_id;							//Packet ID.
		const char *packet_time;				//Packet time.
	
		//Ethernet.
		//---------
		const char *eth_src;
		const char *eth_dst;
		const char *eth_type;
	
		//IP
		//--
												
		const char *ip_src;						//Packet source.
		const char *ip_dst;						//Packet destination.
		const char *ip_type;					//Packet type.

	//Accessor-setter method prototypes.
    //------------------------------------------------------------------------
	public:
		//Packet id.
		//----------
		int get_packet_id();
		const char * get_packet_time();
	
		//Ethernet.
		//---------
		const char * get_eth_src();
		const char * get_eth_dst();
		const char * get_eth_type();
	
		//IP.
		//---
		const char * get_ip_src();
		const char * get_ip_dst();
		const char * get_ip_type();

		//Setter functions.
		//-----------------
		void 			set_packet_id(int id);
		void			set_packet_time(const char *time);
	
		void 			set_packet_src(const char *eth_src, const char *ip_src);
		void 			set_packet_dst(const char *eth_dst, const char *ip_dst);
		void 			set_packet_type(const char *eth_type, const char *ip_type);
};



#endif		/*_SNIFFER_CLASS_DEFS_H*/
