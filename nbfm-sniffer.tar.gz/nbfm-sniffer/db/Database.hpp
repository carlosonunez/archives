#include "sqlite3x.hpp"
#include "sqlite3.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


int CreateDb(const char *dbname);
int OpenConnection(const char *name);
int CloseConnection();
int Insert(const char * source, const char * dest, const char * type, const char *adv_info);
int RetrievePacket(char packnum[]);
//static int Callback();

