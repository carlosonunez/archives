/*******************************************
 * The SNIFFER GUI Error Handler
 * -----------------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date created: 	13 May, 2010
 * Last edited:		13 May, 2010
 *
 * Summary
 * -------
 * Provides a mechanism for dealing with errors
 * gracefully.
 *
 *******************************************/

#ifndef _SNIFFER_GUI_ERROR_H_
#define _SNIFFER_GUI_ERROR_H_

//===========================================
//	Standard includes.
//===========================================

#include <iostream>
#include <string>

//Include Windows library for MessageBox
//or GTK for Linux.
#if defined(WIN32) || defined(_WIN32)
	#include <windows.h>
#else
	#include <gtk/gtk.h>
#endif

#ifndef u_int
	typedef unsigned int u_int;
#endif

//===========================================
//	Prototypes
//===========================================

int			_throw_runtime_error(	std::string		msg);		//Presents a message box for handling errors gracefully.
int			_throw_runtime_error(	std::string		msg,		//Overload to handle fatal exceptions.
									u_int			_ERR_NUM,
									bool			_IS_ERR_FATAL);


#endif		/*	_SNIFFER_GUI_ERROR_H_	*/
