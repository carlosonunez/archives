/*******************************************
 * The SNIFFER GUI Operations Library
 * -----------------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date created: 	13 May, 2010
 * Last edited:		13 May, 2010
 *
 * Summary
 * -------
 * This library provides all GUI functionality
 * for SNIFFER.
 *
 *******************************************/

#ifndef _SNIFFER_GTK_GUI_H_
#define _SNIFFER_GTK_GUI_H_

//Headers for the sniffer
#include "../sniffer_core.hpp"

//============================================
//	Prototypes
//============================================
int _sniffer_gui_main(int argc, char *argv[]);											//Entry point for GUI.
void	addToPacketList();		//GUI packet display method.

#endif /*	_SNIFFER_GTK_GUI_H_		*/
