#!/bin/bash

cp sniffer.glade snifferXML.glade
sed -i 's/interface/glade-interface/g' snifferXML.glade
sed -i 's/glade-glade/glade/g' snifferXML.glade
gtk-builder-convert snifferXML.glade sniffer.xml && g++ -w -g -o sniffer sniffer_gtk_gui.cpp "../sniffer_core.cpp" "../class/sniffer_pkt.cpp" "../db/Database.cpp" "../db/sqlite3x_command.cpp" "../db/sqlite3x_connection.cpp" "../db/sqlite3x_exception.cpp" "../db/sqlite3x_reader.cpp" "../db/sqlite3x_transaction.cpp" "../sniffer_checksums.cpp" "../sniffer_handlers.cpp" `pkg-config --cflags --libs gtk+-2.0 gthread-2.0` -export-dynamic -lpcap -lboost_thread-mt /usr/lib/sqlite-3.6.23.1.so && ./sniffer && rm snifferXML.glade
