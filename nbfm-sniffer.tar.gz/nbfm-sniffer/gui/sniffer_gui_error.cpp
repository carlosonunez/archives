/*******************************************
 * The SNIFFER GUI Error Handler
 * (SOURCE)
 * -----------------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date created: 	13 May, 2010
 * Last edited:		13 May, 2010
 *
 * Summary
 * -------
 * Provides a mechanism for dealing with errors
 * gracefully.
 *
 *******************************************/

#include "sniffer_gui_error.hpp"
using namespace std;

//--------------------------------------------------------------------------------------
//	void _throw_runtime_error(std::string msg):		Presents a non-fatal error message.
//--------------------------------------------------------------------------------------

int	_throw_runtime_error(string msg)
{	return _throw_runtime_error(msg, NULL, false);		}

//------------------------------------------------------------------------------------------------------
//	void _throw_runtime_error(std::string msg, u_int, bool): Overload to account for fatal exceptions.
//------------------------------------------------------------------------------------------------------

int	_throw_runtime_error(string msg, u_int _ERRNUM, bool _IS_ERR_FATAL)
{

//If Windows is detected, SNIFFER will attempt to use the Win32 MessageBox() function
//provided by the Windows SDK. This is more reliable than attempting to use
//GTK from the start.
//---------------------------------------------------------------------------------
#if defined(WIN32) || defined(_WIN32)
	const char *_ERR_TITLE_MSG	=	"Fatal Error";

	//Throw the message box.
	//-----------------------
	MessageBox(		NULL, 
					(LPCSTR) msg.c_str(), 
					(LPCSTR)_ERR_TITLE_MSG, 
					MB_OK | MB_ICONSTOP);

	//Exit with error return code if error is fatal.
	//-----------------------------------------------
	if (_IS_ERR_FATAL)
		return _ERRNUM;
	else
		return 0;
#else
	//TODO: Add GTK compliment.
#endif
}