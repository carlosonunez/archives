/****************************************************
 * The SNIFFER Usability Library
 * -----------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date Created:	23 February, 2010
 *
 * Description
 * -----------
 * Provides methods which external programs can use
 * to work with SNIFFER.
 *
 */
#ifndef SNIFFER_H_
#define SNIFFER_H_

//============================================
//	C/C++ STL libs.
//============================================

#include <stdio.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <signal.h>					//Catch external signals.
#pragma warning (disable:4005)		//Disable macro redef.

using namespace std;

//============================================
//	Networking libs.
//		WIN32: Winsock 2.
//		UNIX:  UNIX sockets.
//============================================

#if defined(WIN32) || defined(_WIN32)
	#include "pcap.h"
	#include <winsock2.h>
	#include <ws2tcpip.h>
	#include "proto/arp.h"
	#include "proto/ip.h"				//IPv4 support.
	#include "proto/ip6.h"			//IPv6 support.
	#include "proto/udp.h"			//UDP
	#include "proto/tcp.h"			//TCP
	#include "proto/ethernet.hpp"			//Ethernet types.
	#include "proto/if_ether.hpp"
#else
	#ifndef __FAVOR_BSD
		#define __FAVOR_BSD
	#endif
	#include <pcap.h>					//pcap usually located in /usr/lib/ by default on Linux/UNIX.
	#include <sys/socket.h>				//UNIX socket programming library.
	#include <netinet/in.h>				//UNIX networking input lilbrary.
	#include <arpa/inet.h>				//UNIX internet library.
	#include <netinet/if_ether.h>		//Ethernet support.
	#include <netinet/ether.h>
	#include <netinet/ip.h>				//IPv4 support.
	#include <netinet/ip6.h>			//IPv6 support.
	#include <netinet/udp.h>			//UDP
	#include <netinet/tcp.h>			//TCP
	#include <net/ethernet.h>			//Ethernet types.
	#include <netdb.h>					//Supports protocol number resolution.
#endif

//--------------------------------------------------------
//	Hand-rolled libs made (with love) by the SNIFFER team.
//--------------------------------------------------------

#include "proto/arp.h"
#include "proto/dns.h"

//========================================================
//	Class definitions
//========================================================

#include "class/sniffer_pkt.h"

//========================================================
//	Core libraries.
//========================================================

#include "sniffer_core.hpp"					//Core functions.
#include "sniffer_handlers.hpp"				//Packet handlers.

//============================================
//	External libraries.
//============================================

//SQLite3
//-------
#include "db/Database.hpp"

#endif /* SNIFFER_H_ */

