/****************************************************
 * The SNIFFER NetBIOS Header
 * -----------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date Created:	15 April, 2010
 *
 * Description
 * -----------
 * Provides support for NetBIOS over IP (NOT NetBEUI over LAN!)
 *
 * For the two of you who actually read these comments:
 * ----------------------------------------------------
 * NetBIOS is a Layer 5 protocol that is, for all intents and purposes,
 * a predecessor to DNS. It uses IP to assign human-friendly names
 * to devices on a network (e.g. KILLER_BEAST_FROM_OUTER_SPACE instead of
 * 192.168.1.12). Windows still uses this for its SMB protocol,
 * though larger networks usually employ DNS instead.
 *
 * Structure of a NetBIOS frame is as follows:
 *		Length (16 bits):			Specifies the length of the frame, usually 0x002C.
 *		Deliminator (16 bits):		MUST be 0xEFFF.
 *		Command (8 bits):			Stores command code.
 *		Data1 (8 bits):				For special requests.
 *		Data2 (8 bits):				For special requests.
 
 ****************************************************/