/*********************************************************************************************************************
 * The SNIFFER Packet Operations Library.
 * -------------------------------------
 *
 * Carlos Nunez		(cnunez@stevens.edu)
 * Kevin Fuhrman	(ktfuhrman@gmail.com)
 * William Best		(wbest@stevens.edu)
 * Mike DiAmore		(mdiamore@stevens.edu)
 *
 * Created on: 	10 April, 2010
 * Last edited:
 *
 * Description
 * -----------
 * Ports ether_ntoa for use in Windows.
 *
 * License:
 * --------
 * /* Copyright (C) 1996,97,2002 Free Software Foundation, Inc.
   This file is part of the GNU C Library.
   Contributed by Ulrich Drepper <drepper@cygnus.com>, 1996.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, write to the Free
   Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307 USA.
  *	*/

#include "if_ether.hpp"

//Prototype for ether_ntoa_r
//--------------------------
char * ether_ntoa_r(const struct ether_addr *addr, char * buf);

//---------------------------------------------------------------------------------------------------------------------
//	ether_ntoa(const struct ether_addr): 	Publically accessible function for creating colon-separated MAC addresses.
//---------------------------------------------------------------------------------------------------------------------
char * ether_ntoa(const struct ether_addr *addr)
{
	static char temp_buf [18];
	return ether_ntoa_r(addr,temp_buf);
}

//---------------------------------------------------------------------------------------------------------------------
//	ether_ntoa_r(const struct ether_addr, char *buf): Internal method for ether_ntoa.
//---------------------------------------------------------------------------------------------------------------------

char * ether_ntoa_r(const struct ether_addr *addr, char *buf)
{
	sprintf (buf, "%x:%x:%x:%x:%x:%x",
			addr->ether_addr_octet[0], 	addr->ether_addr_octet[1],
			addr->ether_addr_octet[2], 	addr->ether_addr_octet[3],
			addr->ether_addr_octet[4], 	addr->ether_addr_octet[5]	);
   return buf;
}
