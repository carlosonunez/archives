/****************************************************
 * The SNIFFER Usability Library
 * Local IP address capture
 * -----------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date Created:	20 May, 2010
 *
 * Description
 * -----------
 * This library gets host IP address.
 ****************************************************/

#if defined(WIN32) || defined(_WIN32)
#ifndef _SNIFFER_GET_IP
#define _SNIFFER_GET_IP

#include <windows.h>
#include <winsock2.h>
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif
#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

void print_localhost();
BOOL setup_wsa();
void cleanup_wsa();
const char* getip();
void report_sockerr();

#endif