/*******************************************************************************
 * The SNIFFER Packet Operations Library.
 * -------------------------------------
 *
 * Carlos Nunez		(cnunez@stevens.edu)
 * Kevin Fuhrman	(ktfuhrman@gmail.com)
 * William Best		(wbest@stevens.edu)
 * Mike DiAmore		(mdiamore@stevens.edu)
 *
 * Description:
 *
 * 		This library contains class definitions for SNIFFER.
 *
 */

//--------------------------------
//	Includes.
//--------------------------------

#include "sniffer_class_defs.hpp"

//--------------------------------
//Accessor functions.
//--------------------------------

//Shared properties.
//------------------
int pkt::get_packet_id()
{return packet_id;}

const char * pkt::get_packet_time()
{return packet_time;}

//Ethernet.
//---------
const char * pkt::get_eth_src()
{return eth_src;}

const char * pkt::get_eth_dst()
{return eth_dst;}

const char * pkt::get_eth_type()
{return eth_type;}

//IP.
//---
const char * pkt::get_ip_src()
{return ip_src;}

const char * pkt::get_ip_dst()
{return ip_dst;}

const char * pkt::get_ip_type()
{return ip_type;}


//Setters.
//-------
void pkt::set_packet_src(const char *eth_src, const char *ip_src)
{eth_src = pkt::eth_src;	ip_src = pkt::ip_src;}

void pkt::set_packet_dst(const char *eth_dst, const char *ip_dst)
{eth_dst = pkt::eth_dst;	ip_dst = pkt::ip_dst;}

void pkt::set_packet_type(const char *eth_type, const char *ip_type)
{eth_type = pkt::eth_type;	ip_type = pkt::ip_type;}

void pkt::set_packet_id(int id)
{id = pkt::packet_id;}

void pkt::set_packet_time(const char *time)
{time = pkt::packet_time;}