/****************************************************
 * The SNIFFER Handlers Library
 * -----------------------------
 *
 * C. Nunez 	(cnunez@stevens.edu)
 * W. Best		(wbest@stevens.edu)
 * K. Fuhrman 	(ktfuhrman@gmail.com)
 * M. DiAmore 	(mdiamore@gmail.com)
 *
 * Date Created:	23 February, 2010
 *
 * Description
 * -----------
 * These are the handlers used by SNIFFER.
 *
 ****************************************************/

#ifndef SNIFFER_HANDLERS_HPP_
#define SNIFFER_HANDLERS_HPP_

//--------------------------------------------
//	Libraries
//--------------------------------------------

#include "sniffer_libraries.hpp"
#include "sniffer_core.hpp"


//--------------------------------------------
//	(A) Handlers and parsers.
//--------------------------------------------

void capture_packet(u_char *args,const struct pcap_pkthdr *pkthdr,const u_char *packet	);

// Layer 2 Parsers.
// ----------------
void parse_ether_header	(const u_char *packet,  const char *time, u_int pkt_id);			//Ethernet (Version 2) Frame Header.
void parse_wifi_header	(const u_char *packet,  const char *time, u_int pkt_id);			//IEEE802.11 Frame Header.
void parse_arp_header	(const u_char *packet);												//ARP over IP.

// Layer 3 Parsers.
// ----------------
void parse_ipv4_datagram(const u_char *packet);			//IPv4 datagram.
void parse_ipv6_datagram(const u_char *packet);			//IPv6 datagram.

// Layer 4 Parsers.
// ----------------
void parse_tcp_header	(const u_char *packet);			//TCP header.
void parse_udp_header	(const u_char *packet);			//UDP header.


// TODO: Write parsers for Layer 5 and 7.
// ---------------------------------------
void parse_dns_header	(const u_char *packet);			//DNS frame parser.

//----------------------------------------
//	(B) Calculation methods.
//----------------------------------------

u_short ipv4_cksum(struct ip *ip, int len);			//IPv4 checksum.


#endif /* SNIFFER_HANDLERS_HPP_ */
